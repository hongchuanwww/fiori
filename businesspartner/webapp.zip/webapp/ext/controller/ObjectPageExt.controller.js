sap.ui.define([],
function (){
    "use strict";
    return {
        approveChange: function(oEvent) {
            alert('approveChange');
        }
    };
});
